package com.demodj.demo_examen.controllers;

import com.demodj.demo_examen.Services.ServiceImplements.StudentsServiceImpl;
import com.demodj.demo_examen.models.Students;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/student")
public class StudensController {
    private final StudentsServiceImpl studentsService;

    public StudensController(StudentsServiceImpl studentsService) {
        this.studentsService = studentsService;
    }
    @GetMapping("/lista-students")
    public String listAllStudents(Model model){
        List<Students> students = studentsService.getAllStudents();
        model.addAttribute("title", "lista de estudiantes");
        model.addAttribute("listaStudents",students);

        return "lista-students";
    }
    /*@GetMapping("/nuevo")
    public  String addStudents(Model model){
        Students students = new Students();
        model.addAttribute("title", "Agregar Estudiante");
        model.addAttribute("student", students);
        return "pages/form-student";
    }
    @PostMapping("/save")
    public String saveStudents(@ModelAttribute("students") Students students){
        studentsService.addStudents(students);
        return "redirect:/students/listar";
    }
    @GetMapping("/showUpdateStudents/{id}")
    public String updateCustomer(@PathVariable(value="id") Long id, Model model){
        Students students = studentsService.getStudentsById(id);
        model.addAttribute("author", students);
        return "pages/form-studentsActualizar";
    }
    @PostMapping("/update")
    public String updateStudents(@ModelAttribute("students") Students students) {
        studentsService.updateStudents(students);
        return "redirect:/author/listar";
    }
    @GetMapping("/delete/{id}")
    public String deleteStudents(@PathVariable(value="id") Long id){
        studentsService.deleteStudents(id);
        return "redirect:/student/listar";

    }
*/

}
