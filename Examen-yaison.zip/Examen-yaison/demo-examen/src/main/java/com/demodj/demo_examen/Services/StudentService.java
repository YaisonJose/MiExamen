package com.demodj.demo_examen.Services;

import com.demodj.demo_examen.models.Students;

import java.util.List;

public interface StudentService {
    List<Students> getAllStudents();
    void addStudents(Students students);
    Students getStudentsById(Long id);
    void deleteStudents(Long id);
    void updateStudents(Students students);
}
