package com.demodj.demo_examen.Services.ServiceImplements;

import com.demodj.demo_examen.Repository.StudentsRepository;
import com.demodj.demo_examen.Services.StudentService;
import com.demodj.demo_examen.models.Students;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentsServiceImpl implements StudentService {

    private final StudentsRepository studentsRepository;

    public StudentsServiceImpl(StudentsRepository studentsRepository) {
        this.studentsRepository = studentsRepository;
    }

    @Override
    public List<Students> getAllStudents() {
        return studentsRepository.findAll();
    }

    @Override
    public void addStudents(Students student) {
        studentsRepository.save(student);
    }

    @Override
    public Students getStudentsById(Long id) {
         Optional<Students> student = studentsRepository.findById(id);
        Students studentsObj = null;
        if (student.isPresent()) {
            studentsObj = student.get();
        } else {
            throw new RuntimeException(
                    "students not found with id " + id
            );
        }
        return studentsObj;
    }


    @Override
    public void deleteStudents(Long id) {
        studentsRepository.deleteById(id);
    }

    @Override
    public void updateStudents(Students students) {
        studentsRepository.save(students);
    }
}






















